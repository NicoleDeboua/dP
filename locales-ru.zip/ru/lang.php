<?php
$dir = basename(dirname(__FILE__));
$LANGUAGES['ru_RU'] = array ($dir, 'Russian (Rus)','Русский (Rus)','rus');

