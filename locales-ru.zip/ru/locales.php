<?php
//$locale_char_set = 'iso-8859-1';
//$locale_char_set = 'Windows-1251';
//$locale_char_set = 'UTF-8';
// 0 = sunday, 1 = monday
$locale_char_set = 'UTF-8';
define( 'LOCALE_FIRST_DAY', 1 );
define( 'LOCALE_TIME_FORMAT', '%I:%M %p');
?>
